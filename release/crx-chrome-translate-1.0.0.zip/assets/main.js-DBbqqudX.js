(function(){(async()=>{let e=[{code:`en`,label:`English`},{code:`ru`,label:`Русский`},{code:`de`,label:`Deutsch`},{code:`es`,label:`Español`},{code:`fr`,label:`Français`},{code:`it`,label:`Italiano`},{code:`pt`,label:`Português`},{code:`zh`,label:`中文`},{code:`ja`,label:`日本語`},{code:`ko`,label:`한국어`},{code:`tr`,label:`Türkçe`},{code:`ar`,label:`العربية`}],t=`deepseek-translator-settings`,n=`deepseek-translator-last-selection`,r=new Map,i,a,o,s,c,l,u,d,f,p,m,h,g,_=``,v=null,y=null,b=null,x=`ru`,S=`en`,C=!1,w=!1,T=null,E=null;function ee(e){return(e||`s`).slice(0,1).toLowerCase()}function D(){let t=navigator.language?.split(`-`)[0]?.toLowerCase();return e.some(e=>e.code===t)?t:`en`}function O(t){return e.find(e=>e.code===t)?.label??t}function k(e){return e?e===`he`?`iw`:e:`en`}function A(e){return/[\u0400-\u04FF]/.test(e)?`ru`:/[\u3040-\u30ff\u31f0-\u31ff]/.test(e)?`ja`:/[\uac00-\ud7af]/.test(e)?`ko`:/[\u4e00-\u9fff]/.test(e)?`zh`:/[a-z]/i.test(e)?`en`:k(navigator.language?.split(`-`)[0])||`en`}function j(e){return e?!!e.closest(`input, textarea, [contenteditable=""], [contenteditable="true"]`):!1}function te(){return typeof self<`u`&&`Translator`in self}async function M(){let e=D();if(typeof chrome<`u`&&chrome?.storage?.local)return{targetLanguage:e,shortcutKey:`s`,...(await chrome.storage.local.get(t))[t]||{}};try{let n=localStorage.getItem(t);return{targetLanguage:e,shortcutKey:`s`,...n?JSON.parse(n):{}}}catch{return{targetLanguage:e,shortcutKey:`s`}}}async function N(e){if(typeof chrome<`u`&&chrome?.storage?.local){await chrome.storage.local.set({[n]:e});return}try{localStorage.setItem(n,JSON.stringify(e))}catch{}}async function ne(){return`LanguageDetector`in self?(i||=self.LanguageDetector.create(),i):null}async function P(e){let t=await ne();if(!t)return A(e);try{let n=(await t.detect(e))?.[0];if(n?.detectedLanguage&&n.confidence>=.5)return k(n.detectedLanguage)}catch{return A(e)}return A(e)}async function F(e,t){let n=`${e}:${t}`;return r.has(n)||r.set(n,self.Translator.create({sourceLanguage:e,targetLanguage:t}).then(async e=>(e?.ready&&await e.ready,e))),r.get(n)}async function I(e,t,n){let r=k(t),i=k(n);if(r===i)return{translatedText:e,sourceLanguage:r,targetLanguage:i};if(await self.Translator.availability({sourceLanguage:r,targetLanguage:i})===`unavailable`)throw Error(`Эта языковая пара пока не поддерживается встроенным переводчиком Chrome.`);return{translatedText:await(await F(r,i)).translate(e),sourceLanguage:r,targetLanguage:i}}function L(e,t,n){return Math.min(Math.max(e,t),n)}function re(){a=document.createElement(`div`),a.id=`local-translator-selection-root`,a.style.all=`initial`,document.documentElement.append(a),o=a.attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=`
      :host {
        all: initial;
      }

      .wrap {
        position: fixed;
        inset: 0;
        pointer-events: none;
        z-index: 2147483647;
        font-family: Manrope, "Segoe UI", sans-serif;
        color: #171717;
      }

      button,
      select {
        font: inherit;
      }

      .trigger {
        position: fixed;
        pointer-events: auto;
        border: 0;
        border-radius: 7px;
        background: #4f46e5;
        color: #fff;
        width: 30px;
        height: 30px;
        padding: 0;
        overflow: visible;
        cursor: pointer;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
      }

      .trigger:hover {
        background: #4338ca;
      }

      .trigger svg {
        display: block;
        width: 32px;
        height: 32px;
        margin: -1px;
      }

      .panel {
        position: fixed;
        min-width: 280px;
        min-height: 180px;
        max-width: calc(100vw - 16px);
        max-height: calc(100vh - 16px);
        border: 1px solid #d7d7d7;
        background: #fff;
        pointer-events: auto;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.12);
        box-sizing: border-box;
      }

      .panel-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        height: 26px;
        padding: 0 8px;
        border-bottom: 1px solid #ededed;
        background: #fafafa;
        cursor: grab;
        user-select: none;
      }

      .panel-bar:active {
        cursor: grabbing;
      }

      .panel-title {
        font-size: 11px;
        color: #8b8b8b;
      }

      .panel-close {
        border: 0;
        background: transparent;
        color: #8b8b8b;
        font-size: 14px;
        line-height: 1;
        padding: 0;
        cursor: pointer;
      }

      .panel-close:hover {
        color: #4b4b4b;
      }

      .panel-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .panel-pin {
        position: relative;
        width: 14px;
        height: 14px;
        border: 1px solid #cfcfcf;
        border-radius: 999px;
        background: linear-gradient(180deg, #ffffff 0%, #f1f1f1 100%);
        box-shadow:
          0 1px 0 rgba(255, 255, 255, 0.9) inset,
          0 1px 2px rgba(0, 0, 0, 0.12);
        cursor: pointer;
        padding: 0;
        transition:
          transform 120ms ease,
          box-shadow 120ms ease,
          border-color 120ms ease,
          background 120ms ease;
      }

      .panel-pin::before {
        content: "";
        position: absolute;
        inset: 4px;
        border-radius: 999px;
        background: #8b8b8b;
        transition: background 120ms ease, transform 120ms ease;
      }

      .panel-pin:hover {
        border-color: #adadad;
      }

      .panel-pin.active {
        transform: translateY(1px) scale(0.96);
        background: linear-gradient(180deg, #ececec 0%, #dcdcdc 100%);
        box-shadow:
          0 1px 2px rgba(0, 0, 0, 0.08) inset,
          0 0 0 1px rgba(0, 0, 0, 0.02);
      }

      .panel-pin.active::before {
        background: #4f46e5;
        transform: scale(0.88);
      }

      .panel-body {
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .hidden {
        display: none;
      }

      .section {
        padding: 10px 12px;
        border-bottom: 1px solid #ededed;
        min-height: 0;
      }

      .section:last-child {
        border-bottom: 0;
      }

      .section-text {
        flex: 1 1 0;
        display: flex;
        flex-direction: column;
        min-height: 0;
      }

      .section-controls {
        flex: 0 0 auto;
      }

      .source {
        flex: 1 1 auto;
        min-height: 0;
        font-size: 13px;
        line-height: 1.5;
        white-space: pre-wrap;
        word-break: break-word;
        overflow: auto;
      }

      .row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }

      .select {
        flex: 1;
        min-width: 0;
        border: 1px solid #d7d7d7;
        background: #fff;
        color: #171717;
        padding: 6px 8px;
        font-size: 12px;
      }

      .target {
        font-size: 11px;
        color: #8b8b8b;
        white-space: nowrap;
      }

      .result {
        flex: 1 1 auto;
        min-height: 0;
        font-size: 13px;
        line-height: 1.5;
        white-space: pre-wrap;
        word-break: break-word;
        overflow: auto;
      }

      .status {
        font-size: 11px;
        color: #8b8b8b;
      }

      .error {
        color: #b42318;
      }

      .resize-handle {
        position: absolute;
        right: 0;
        bottom: 0;
        width: 14px;
        height: 14px;
        cursor: nwse-resize;
      }

      .resize-handle::before {
        content: "";
        position: absolute;
        right: 3px;
        bottom: 3px;
        width: 7px;
        height: 7px;
        border-right: 1px solid #9a9a9a;
        border-bottom: 1px solid #9a9a9a;
      }
    `;let n=document.createElement(`div`);n.className=`wrap`,s=document.createElement(`button`),s.type=`button`,s.className=`trigger hidden`,s.setAttribute(`aria-label`,`Перевести`),s.innerHTML=`
      <svg viewBox="0 0 768 544" aria-hidden="true" focusable="false">
        <path fill="#ffffff" stroke="#ffffff" stroke-width="8" stroke-linejoin="round" d="M415.787323,417.003296 C430.605255,420.421387 444.997650,423.825378 459.442596,426.989349 C463.897247,427.965088 467.219116,430.167145 470.314270,433.478546 C496.932648,461.956818 523.248718,490.720947 550.462219,518.640015 C551.992859,520.210388 554.707092,521.583923 553.574524,524.335571 C552.460938,527.040833 549.595581,526.145081 547.359558,526.354065 C515.243042,529.355896 485.756317,520.796997 457.752441,505.856537 C456.029877,504.937561 454.541687,503.470947 453.150116,502.056793 C439.125946,487.804840 425.120728,473.533966 411.178802,459.201599 C409.220306,457.188263 407.613770,456.499817 404.686066,457.720764 C376.251556,469.579285 346.505707,474.382568 315.889435,472.039581 C296.272980,470.538330 277.243439,465.485382 259.133362,457.577148 C221.051819,440.947815 191.782669,414.418915 171.446793,378.237091 C162.545258,362.399384 155.874023,345.679779 152.433014,327.622467 C150.304153,316.450897 149.201202,305.288605 148.902390,294.003448 C148.816650,290.766022 147.691132,289.166229 144.618454,288.395355 C131.540054,285.114258 118.517403,281.608490 105.422737,278.395294 C93.621361,275.499451 81.745689,272.907288 69.921547,270.102173 C68.220100,269.698547 66.045586,269.497986 65.752159,267.163696 C65.458084,264.824097 67.637146,264.103577 69.078926,263.242310 C84.227104,254.193344 99.495506,245.345184 114.622719,236.261703 C128.179184,228.121399 141.244202,218.854324 156.211746,213.626480 C166.374908,210.076721 172.164490,203.636765 177.706985,194.774643 C198.348389,161.770264 227.053101,138.031082 263.313995,123.379890 C284.720428,114.730621 306.904633,109.866837 329.841064,109.891617 C372.467987,109.937668 410.426270,123.794456 443.539948,150.766830 C470.056885,172.365906 488.822021,199.297607 499.558044,231.791183 C501.825317,238.653152 502.854187,238.970749 509.500214,235.169647 C570.348572,200.368225 630.523193,164.417068 690.944336,128.886642 C699.268555,123.991600 707.618652,119.140129 715.984680,114.316872 C720.301147,111.828293 722.503601,112.882835 722.925842,117.835548 C724.634460,137.876266 720.802246,156.872284 711.749084,174.799881 C697.476929,203.062317 675.762085,223.694931 648.230225,239.208801 C613.997253,258.498627 580.465515,279.032013 546.611755,298.995972 C535.421387,305.595123 524.185425,312.117432 512.943970,318.629364 C506.838867,322.165924 505.462952,325.156769 506.777527,332.573853 C508.552246,333.679901 509.915771,332.461823 511.307526,331.662994 C547.841431,310.692871 584.370850,289.714966 620.893311,268.724976 C632.731506,261.921356 644.539246,255.064728 656.378052,248.262161 C662.835266,244.551849 665.033203,245.968384 665.299744,253.684021 C665.704224,265.389526 662.841431,276.385406 658.338135,287.046387 C646.753113,314.472443 626.448914,333.522461 601.024841,348.177948 C561.347290,371.049805 522.033447,394.552612 482.551422,417.764038 C479.108185,419.788361 475.430817,421.436249 472.093903,423.614014 C467.876343,426.366577 464.902283,425.334930 461.809784,421.674835 C447.636139,404.899872 438.338928,385.883911 434.978394,364.118774 C433.847992,356.797394 435.821533,349.876587 438.863983,343.306641 C448.764160,321.928223 452.222870,299.299286 449.517578,276.195953 C444.523834,233.549164 422.008148,202.294510 384.096832,182.564224 C363.268066,171.724289 340.797668,168.259949 317.325439,170.973953 C284.317169,174.790527 257.008331,189.237808 236.182434,214.967300 C221.420624,233.204865 213.360199,254.421967 210.991959,277.983795 C208.628677,301.496033 212.280960,323.912292 222.462296,344.942627 C240.414871,382.024963 270.610809,403.644867 310.756561,411.395294 C325.076630,414.159912 339.680267,413.883759 353.915192,410.639709 C365.828094,407.924866 377.423615,409.823822 389.131683,411.171539 C398.064850,412.199860 406.606506,415.101288 415.787323,417.003296 z"></path>
        <path fill="#ffffff" stroke="#ffffff" stroke-width="8" stroke-linejoin="round" d="M279.217529,222.064590 C289.884369,214.592026 301.562469,219.990494 306.545197,228.398376 C312.002808,237.607620 308.017853,248.890488 297.835541,253.918732 C288.459839,258.548676 276.912750,253.849457 272.727509,243.700729 C269.631592,236.193466 271.837524,228.569305 279.217529,222.064590 z"></path>
      </svg>
    `,s.addEventListener(`click`,()=>{X()}),c=document.createElement(`div`),c.className=`panel hidden`,l=document.createElement(`div`),l.className=`panel-bar`;let r=document.createElement(`div`);r.className=`panel-title`,r.textContent=`Перевод`;let i=document.createElement(`div`);i.className=`panel-actions`,u=document.createElement(`button`),u.type=`button`,u.className=`panel-pin`,u.setAttribute(`aria-label`,`Закрепить`),u.addEventListener(`mousedown`,e=>{e.preventDefault(),e.stopPropagation()}),u.addEventListener(`click`,()=>{G(!w)}),d=document.createElement(`button`),d.type=`button`,d.className=`panel-close`,d.setAttribute(`aria-label`,`Закрыть`),d.textContent=`×`,d.addEventListener(`mousedown`,e=>{e.stopPropagation()}),d.addEventListener(`click`,()=>{G(!1),B()}),i.append(u,d),l.append(r,i),l.addEventListener(`mousedown`,e=>{let t=e.composedPath?.()??[];t.includes(d)||t.includes(u)||(T={offsetX:e.clientX-c.offsetLeft,offsetY:e.clientY-c.offsetTop},e.preventDefault())});let _=document.createElement(`div`);_.className=`section section-text`,f=document.createElement(`div`),f.className=`source`,_.append(f);let v=document.createElement(`div`);v.className=`section section-controls`;let y=document.createElement(`div`);y.className=`row`,p=document.createElement(`select`),p.className=`select`;for(let t of e){let e=document.createElement(`option`);e.value=t.code,e.textContent=t.label,p.append(e)}p.addEventListener(`change`,()=>{S=p.value,Y(S)}),m=document.createElement(`div`),m.className=`target`,y.append(p,m),v.append(y);let b=document.createElement(`div`);b.className=`section section-text`,h=document.createElement(`div`),h.className=`result`,g=document.createElement(`div`),g.className=`status`,b.append(h,g);let x=document.createElement(`div`);x.className=`panel-body`,x.append(_,v,b);let C=document.createElement(`div`);C.className=`resize-handle`,C.addEventListener(`mousedown`,e=>{T={type:`resize`,startX:e.clientX,startY:e.clientY,startWidth:c.offsetWidth,startHeight:c.offsetHeight},e.preventDefault(),e.stopPropagation()}),c.append(l,x,C),n.append(s,c),o.append(t,n)}function R(e,t,n=0){let r=n||e.offsetWidth||E?.width||320,i=e.offsetHeight||E?.height||180,a=L(t.left,8,window.innerWidth-r-8),o=Math.min(t.bottom+20,window.innerHeight-i-8);e.style.left=`${a}px`,e.style.top=`${o}px`}function z(){s.classList.add(`hidden`)}function ie(){c.classList.add(`hidden`),C=!1}function B(){_=``,v=null,y=null,b=null,T=null,U(),G(!1),z(),ie()}function V(e,t){let n=c.offsetWidth||E?.width||320,r=c.offsetHeight||E?.height||180;c.style.left=`${L(e,8,window.innerWidth-n-8)}px`,c.style.top=`${L(t,8,window.innerHeight-r-8)}px`}function H(){E&&(c.style.width=`${E.width}px`,c.style.height=`${E.height}px`)}function U(){E=null,c&&(c.style.width=``,c.style.height=``)}function W(){if(!C||E)return;c.style.width=`auto`,c.style.height=`auto`;let e=L(Math.ceil(Math.max(320,c.scrollWidth)),280,window.innerWidth-16),t=L(Math.ceil(Math.max(180,c.scrollHeight)),180,window.innerHeight-16);c.style.width=`${e}px`,c.style.height=`${t}px`}function G(e){w=e,u.classList.toggle(`active`,w),u.setAttribute(`aria-label`,w?`Открепить`:`Закрепить`)}function ae(e,t){if(!e||e.rangeCount===0)return{x:t.right,y:t.bottom};let n=e.getRangeAt(0),r=n.endContainer,i=n.endOffset;try{if(r?.nodeType===Node.TEXT_NODE){let e=document.createRange(),t=Math.max(0,i-1);e.setStart(r,t),e.setEnd(r,i);let n=e.getBoundingClientRect();if(n&&(n.width||n.height))return{x:n.right,y:n.bottom}}else if(r?.childNodes?.length){let e=Math.max(0,Math.min(i-1,r.childNodes.length-1)),t=r.childNodes[e];if(t){let e=document.createRange();e.selectNodeContents(t);let n=e.getBoundingClientRect();if(n&&(n.width||n.height))return{x:n.right,y:n.bottom}}}}catch{return{x:t.right,y:t.bottom}}return{x:t.right,y:t.bottom}}function K(){if(!y)return v;try{let e=y.getBoundingClientRect();if(e&&(e.width||e.height))return e}catch{return v}return v}async function oe(e,t){return k(await P(e).catch(()=>A(e)))!==k(t)}function q(){let e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)return null;let t=e.toString();if(!t.trim())return null;let n=e.getRangeAt(0),r=n.getBoundingClientRect();return!r||!r.width&&!r.height?null:{text:t,rect:r,range:n.cloneRange(),anchor:ae(e,r)}}async function se(){x=(await M()).targetLanguage||D(),m.textContent=O(x)}function J(e,t){let n=e?.x??t.right,r=e?.y??t.bottom;s.classList.remove(`hidden`),s.style.left=`${L(n-15,8,window.innerWidth-38)}px`,s.style.top=`${L(r+20,8,window.innerHeight-38)}px`}async function Y(e){h.textContent=``,g.textContent=`Перевод...`,g.classList.remove(`error`),W();try{let t=await I(_,e,x);S=t.sourceLanguage,p.value=t.sourceLanguage,h.textContent=t.translatedText,g.textContent=``,W()}catch(e){h.textContent=``,g.textContent=e.message||`Не удалось перевести текст.`,g.classList.add(`error`),W()}}async function X(){if(!(!_||!v)){if(z(),c.classList.remove(`hidden`),C=!0,E?H():U(),f.textContent=_,h.textContent=``,g.textContent=`Перевод...`,g.classList.remove(`error`),W(),w||R(c,K()),await se(),W(),!te()){g.textContent=`Нужен Chrome 138+ с поддержкой Built-in AI Translator API.`,g.classList.add(`error`),W();return}S=await P(_).catch(()=>`en`),p.value=S,Y(S)}}async function Z(e=null){let t=document.activeElement;if(j(t))return;let n=q();if(!n)return;let r=await M();_=n.text.slice(0,2e3),v=n.rect,y=n.range,b=e||n.anchor,x=r.targetLanguage||D(),N(_),await X()}async function Q(e=null){if(C&&w)return;let t=document.activeElement;if(j(t)){C||B();return}let n=q();if(!n){B();return}let r=(await M()).targetLanguage||D();if(!await oe(n.text,r)){C||B();return}_=n.text.slice(0,2e3),v=n.rect,y=n.range,b=e||n.anchor,x=r,N(_),J(b,n.rect)}function ce(e){if(T)return;let t=e.composedPath?.()??[];if(!(t.includes(a)||t.includes(s)||t.includes(c))){if(C&&!w){B();return}C||B()}}function le(e){if(!(!T||!C)){if(T.type===`resize`){E={width:L(T.startWidth+(e.clientX-T.startX),280,window.innerWidth-16),height:L(T.startHeight+(e.clientY-T.startY),180,window.innerHeight-16)},H(),V(c.offsetLeft,c.offsetTop);return}V(e.clientX-T.offsetX,e.clientY-T.offsetY)}}function ue(){T?.type===`resize`&&(E={width:c.offsetWidth,height:c.offsetHeight}),T=null}function $(){if(C){if(w)return;let e=K();if(!e)return;v=e,E||W(),R(c,e);return}if(y){let e=K();if(!e){B();return}v=e,J(b||{x:e.right,y:e.bottom},e)}}re(),typeof chrome<`u`&&chrome?.runtime?.onMessage&&chrome.runtime.onMessage.addListener(e=>{e?.type===`invoke-translation`&&Z()}),document.addEventListener(`mouseup`,e=>{let t={x:e.clientX,y:e.clientY};setTimeout(()=>{Q(t)},0)}),document.addEventListener(`keydown`,async e=>{if(!e.altKey||!e.shiftKey||e.ctrlKey||e.metaKey)return;let t=ee((await M()).shortcutKey);e.key.toLowerCase()===t&&(e.preventDefault(),Z())}),document.addEventListener(`keyup`,e=>{(e.key.startsWith(`Arrow`)||e.key===`Shift`)&&setTimeout(Q,0)}),document.addEventListener(`mousedown`,ce,!0),document.addEventListener(`mousemove`,le,!0),document.addEventListener(`mouseup`,ue,!0),window.addEventListener(`scroll`,$,!0),window.addEventListener(`resize`,$)})();})()
